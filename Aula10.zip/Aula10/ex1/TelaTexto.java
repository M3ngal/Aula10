package ex1;

import javax.swing.*;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaTexto extends JFrame implements ActionListener{
    private JButton b1;
    private JButton b2;
    private JButton b3;
    private JTextField text;
    private JLabel label;

    public TelaTexto(){
        super("Texto");
        b1 = new JButton("Mostrar");
        b2 = new JButton("Limpar");
        b3 = new JButton("Sair");
        text = new JTextField("", 10);
        label = new JLabel("Texto");
        Container t = getContentPane();
        t.setLayout(new BorderLayout());
        JPanel pn = new JPanel(new GridLayout(1,2));
        pn.add(label);
        pn.add(text);
        t.add(pn, BorderLayout.NORTH);
        t.add(b1,BorderLayout.WEST);
        t.add(b2,BorderLayout.CENTER);
        t.add(b3,BorderLayout.EAST);
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        setSize(200,150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource() == b1){
            JOptionPane.showMessageDialog(null, text.getText());
        }
        if (e.getSource() == b2){
            text.setText("");
        }
        if (e.getSource() == b3){
            System.exit(0);
        }

    }
}