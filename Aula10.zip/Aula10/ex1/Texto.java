package ex1;

public class Texto{
    public static void main(String[] args){
    
        TelaTexto tela = new TelaTexto();
    }
}