package ex3;

public class Tarefeiro extends Empregado{
    private double pagamento;

    public Tarefeiro(String nome, String sobrenome, String cpf, double pagamento) {
        super(nome, sobrenome, cpf);
        this.pagamento = pagamento;
    }

    public Tarefeiro(){
        super("G","H","4");
        this.pagamento = 450.0;
    }

    public double salario(){
        return this.pagamento;
    }
}
