package ex3;

import javax.swing.*;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Tela extends JFrame implements ActionListener{
    private JButton b1;
    private JButton b2;
    private JButton b3;
    private JButton b4;
    private JButton b5;
    private JLabel label;
    private Horista h;
    private Comissionado c;
    private Mensalista m;
    private Tarefeiro ta;

    public Tela(){
        super("Empregados");
        h = new Horista();
        c = new Comissionado();
        m = new Mensalista();
        ta = new Tarefeiro();
        b1 = new JButton("Comissionado");
        b2 = new JButton("Horista");
        b3 = new JButton("Mensalista");
        b4 = new JButton("Tarefeiro");
        b5 = new JButton("Empregado");
        label = new JLabel(" Opções de Emrpegados: ");
        Container t = getContentPane();
        t.setLayout(new FlowLayout());
        t.add(label);
        t.add(b1);
        t.add(b2);
        t.add(b3);
        t.add(b4);
        t.add(b5);
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
        b5.addActionListener(this);
        setSize(700,100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource() == b1){
            JOptionPane.showMessageDialog(null, "Comissionado: " + c.dados());
        }
        if (e.getSource() == b2){
            JOptionPane.showMessageDialog(null, "Horista: " + h.dados());
        }
        if (e.getSource() == b3){
            JOptionPane.showMessageDialog(null, "Mensalista: " + m.dados());
        }
        if (e.getSource() == b4){
            JOptionPane.showMessageDialog(null, "Tarefeiro: " + ta.dados());
        }
        if (e.getSource() == b5){
            JOptionPane.showMessageDialog(null, "Empregados: \nComissionado: " + c.dados() + "\nHorista: " + h.dados() + "\nMensalista: " + m.dados() + "\nTarefeiro: " + ta.dados());
        }
    }

}
