package ex4;

public class Horista extends Empregado{
    private double salario;

    public Horista(String nome, String sobrenome, String cpf, double salario) {
        super(nome, sobrenome, cpf);
        this.salario = salario;
    }

    public Horista(){
        super("C","C", "2");
        this.salario = 750.0;
    }

    public double salario(){
        return this.salario;
    }
}
