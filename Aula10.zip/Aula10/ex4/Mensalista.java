package ex4;

public class Mensalista extends Empregado{
    private double salario;

    public Mensalista(String nome, String sobrenome, String cpf, double salario) {
        super(nome, sobrenome, cpf);
        this.salario = salario;
    }

    public Mensalista(){
        super("E","F","3");
        this.salario = 650.0;
    }

    public double salario(){
        return this.salario;
    }
}
