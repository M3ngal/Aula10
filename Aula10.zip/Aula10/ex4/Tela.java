package ex4;

import ex3.Comissionado;
import ex3.Horista;
import ex3.Mensalista;
import ex3.Tarefeiro;

import javax.swing.*;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Tela extends JFrame implements ActionListener{
    private JButton b1;
    private JButton b2;
    private JButton b3;
    private JButton b4;
    private JButton b5;
    private JButton b6;
    private JButton b7;
    private JLabel label;
    private Horista h;
    private Comissionado c;
    private Mensalista m;
    private Tarefeiro ta;
    private PessoaFisica p;
    private Desempregado d;


    public Tela(){
        super("Empregados");
        h = new Horista();
        c = new Comissionado();
        m = new Mensalista();
        ta = new Tarefeiro();
        p = new PessoaFisica();
        d = new Desempregado("X","Y","9",8000.0);
        b1 = new JButton("Comissionado");
        b2 = new JButton("Horista");
        b3 = new JButton("Mensalista");
        b4 = new JButton("Tarefeiro");
        b5 = new JButton("Empregado");
        b6 = new JButton("Desempregado");
        b7 = new JButton("Pessoas");
        label = new JLabel(" Opções de Emrpegados: ");
        Container t = getContentPane();
        t.setLayout(new FlowLayout());
        t.add(label);
        t.add(b1);
        t.add(b2);
        t.add(b3);
        t.add(b4);
        t.add(b5);
        t.add(b6);
        t.add(b7);
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
        b5.addActionListener(this);
        b6.addActionListener(this);
        b7.addActionListener(this);
        setSize(900,100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource() == b1){
            JOptionPane.showMessageDialog(null, "Comissionado: " + c.dados());
        }
        if (e.getSource() == b2){
            JOptionPane.showMessageDialog(null, "Horista: " + h.dados());
        }
        if (e.getSource() == b3){
            JOptionPane.showMessageDialog(null, "Mensalista: " + m.dados());
        }
        if (e.getSource() == b4){
            JOptionPane.showMessageDialog(null, "Tarefeiro: " + ta.dados());
        }
        if (e.getSource() == b5){
            JOptionPane.showMessageDialog(null, "Empregados: \nComissionado: " + c.dados() + "\nHorista: " + h.dados() + "\nMensalista: " + m.dados() + "\nTarefeiro: " + ta.dados());
        }
        if (e.getSource() == b6){
            JOptionPane.showMessageDialog(null, "Desempregados: " + d.dados());
        }
        if (e.getSource() == b7){
            JOptionPane.showMessageDialog(null,  "Pessoas: " + p.dados() + "\nDesempregados: " + d.dados() + "\nEmpregados: \nComissionado: " + c.dados() + "\nHorista: " + h.dados() + "\nMensalista: " + m.dados() + "\nTarefeiro: " + ta.dados());
        }
    }
}