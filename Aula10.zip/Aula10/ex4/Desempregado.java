package ex4;

public class Desempregado extends PessoaFisica {
    private double seguroDesemprego;

    public Desempregado(String nome, String sobrenome, String cpf, double seguroDesemprego){
        super(nome, sobrenome, cpf);
        this.seguroDesemprego = seguroDesemprego;
    }
    public Desempregado(){
        this.seguroDesemprego = 0.0;
    }
    
    public double getSeguroDesemprego(){
        return seguroDesemprego;
    }

    public  void setSeguroDesemprego(double seguroDesemprego){
        this.seguroDesemprego = seguroDesemprego;
    }

    public String dados(){
        return super.dados() + "\nSeguro Desemprego: " + seguroDesemprego;
    }
}
