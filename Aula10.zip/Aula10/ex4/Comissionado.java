package ex4;

public class Comissionado extends Mensalista {
    private double comissao;

    public Comissionado(String nome, String sobrenome, String cpf, double salario, double comissao) {
        super(nome, sobrenome, cpf, salario);
        this.comissao = comissao;
    }

    public Comissionado(){
        super("A","B", "1", 1000.0);
        this.comissao = 500.0;
    }

    public double salario(){
        return super.salario() + comissao;
    }
}
