package ex2;

import javax.swing.*;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Display extends JFrame implements ActionListener{
    private JButton b1;
    private JButton b2;
    private JButton b3;
    private JLabel label;
    private Relogio r;

    public Display(){
        super("Relogio");
        r = new Relogio();
        b1 = new JButton("TicTac");
        b2 = new JButton("Hora");
        b3 = new JButton("Minuto");
        label = new JLabel(r.mostra());
        Container t = getContentPane();
        t.setLayout(new BorderLayout());
        t.add(label,BorderLayout.NORTH);
        t.add(b1,BorderLayout.WEST);
        t.add(b2,BorderLayout.CENTER);
        t.add(b3,BorderLayout.EAST);
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        setSize(700,200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource() == b1){
            r.ticTac();
            label.setText(r.mostra());
        }
        if (e.getSource() == b2){
            r.setHora();
            label.setText(r.mostra());
        }
        if (e.getSource() == b3){
            r.setMinuto();
            label.setText(r.mostra());
        }

    }
}