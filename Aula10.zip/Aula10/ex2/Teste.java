package ex2;

public class Teste {
    public static void main(String[] args){
        Display d = new Display();
    }
}
