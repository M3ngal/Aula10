package ex5;

public class Teste {
    public static void main(String[] args){
        Calculadora calculadora = new Calculadora();
    }
}
