package ex5;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JPanel;
import java.awt.event.ActionListener;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.GridLayout;
import java.awt.Font;

public class Calculadora extends JFrame implements ActionListener {
    private JButton zeroButton;
    private JButton oneButton;
    private JButton twoButton;
    private JButton threeButton;
    private JButton fourButton;
    private JButton fiveButton;
    private JButton sixButton;
    private JButton sevenButton;
    private JButton eightButton;
    private JButton nineButton;
    private JButton plusButton;
    private JButton subtButton;
    private JButton multButton;
    private JButton divButton;
    private JButton equalButton;
    private JButton clearButton;
    private JTextField showField;
    private String display;
    private int result;

    Calculadora() {
        super("Calculadora");
        display = "";
        zeroButton = new JButton("0");
        oneButton = new JButton("1");
        twoButton = new JButton("2");
        threeButton = new JButton("3");
        fourButton = new JButton("4");
        fiveButton = new JButton("5");
        sixButton = new JButton("6");
        sevenButton = new JButton("7");
        eightButton = new JButton("8");
        nineButton = new JButton("9");
        plusButton = new JButton("+");
        subtButton = new JButton("-");
        multButton = new JButton("*");
        divButton = new JButton("/");
        equalButton = new JButton("=");
        clearButton = new JButton("C");
        showField = new JTextField("                                                                              0");
        Font font = showField.getFont().deriveFont(Font.PLAIN, 40f);
        showField.setFont(font);
        showField.setEditable(false);

        Container calculatorContainer = getContentPane();
        calculatorContainer.setLayout(new BorderLayout(8, 6));
        JPanel numPad = new JPanel(new GridLayout(4, 4,8, 6));

        numPad.add(sevenButton);
        numPad.add(eightButton);
        numPad.add(nineButton);
        numPad.add(plusButton);
        numPad.add(fourButton);
        numPad.add(fiveButton);
        numPad.add(sixButton);
        numPad.add(subtButton);
        numPad.add(oneButton);
        numPad.add(twoButton);
        numPad.add(threeButton);
        numPad.add(multButton);
        numPad.add(zeroButton);
        numPad.add(clearButton);
        numPad.add(equalButton);
        numPad.add(divButton);

        calculatorContainer.add(showField, BorderLayout.NORTH);
        calculatorContainer.add(numPad, BorderLayout.CENTER);

        zeroButton.addActionListener(this);
        oneButton.addActionListener(this);
        twoButton.addActionListener(this);
        threeButton.addActionListener(this);
        fourButton.addActionListener(this);
        fiveButton.addActionListener(this);
        sixButton.addActionListener(this);
        sevenButton.addActionListener(this);
        eightButton.addActionListener(this);
        nineButton.addActionListener(this);
        plusButton.addActionListener(this);
        subtButton.addActionListener(this);
        multButton.addActionListener(this);
        divButton.addActionListener(this);
        equalButton.addActionListener(this);
        clearButton.addActionListener(this);

        setSize(900, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == zeroButton) {
            display += "0";
        }if (e.getSource() == oneButton) {
            display += "1";
        }if (e.getSource() == twoButton) {
            display += "2";
        }if (e.getSource() == threeButton) {
            display += "3";
        }if (e.getSource() == fourButton) {
            display += "4";
        }if (e.getSource() == fiveButton) {
            display += "5";
        }if (e.getSource() == sixButton) {
            display += "6";
        }if (e.getSource() == sevenButton) {
            display += "7";
        }if (e.getSource() == eightButton) {
            display += "8";
        }if (e.getSource() == nineButton) {
            display += "9";
        }if (e.getSource() == plusButton) {
            display += "+";
        }if (e.getSource() == subtButton) {
            display += "-";
        }if (e.getSource() == multButton) {
            display += "*";
        }if (e.getSource() == divButton) {
            display += "/";
        }if (e.getSource() == clearButton) {
            display = "";
        }

        showField.setText(display);

        if (e.getSource() == equalButton) {
            calculatorProcessing();
        }
    }

    public void calculatorProcessing() {
        String operator = "";

        for (int i = 0; i < display.length(); i++) {
            char ch = display.charAt(i);
            if (ch == '+' || ch == '-' || ch == '*' || ch == '/') {
                operator = Character.toString(ch);
            }
        }

        int operand1 = Integer.parseInt(display.substring(0, display.indexOf(operator)));
        int operand2 = Integer.parseInt(display.substring(display.indexOf(operator) + 1));

        switch (operator) {
            case "+":
                result = operand1 + operand2;
                break;

            case "-":
                result = operand1 - operand2;
                break;

            case "*":
                result = operand1 * operand2;
                break;

            case "/":
                result = operand1 / operand2;
                break;

            default:
                break;
        }

        showField.setText(Integer.toString(result));
        display = Integer.toString(result);
    }
}